export const apiKey = 'f47c719fe999a212c47cfc11d62f4e37'
export const imgUrl = 'https://image.tmdb.org/t/p/w500/'
export const imgUrlFull = 'https://image.tmdb.org/t/p/original/'