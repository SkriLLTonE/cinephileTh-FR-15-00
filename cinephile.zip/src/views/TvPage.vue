<template>
    <div>
        serials
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped></style>